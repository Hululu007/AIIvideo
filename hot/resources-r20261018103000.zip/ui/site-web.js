/* 自动生成，不要手改 —— 改 site-default.json 然后重新打包。
 * 生成器：work/shells/gen-web-config.py
 * 浏览器读不了 JSON（页面 CSP 是 connect-src 'none'），所以包一层赋值。
 */
window.HG_SITE = {
    "coverOrigin": "https://pic.drleao.cn",
    "categories": {
      "ai-duanju": 24,
      "ai-manju": 25,
      "ai-huanlian": 26,
      "ai-mogai": 27
    },
    "firstPageSize": 8,
    "pageSize": 20,
    "paths": {
      "home": "/api/home",
      "detail": "/api/videos/{id}",
      "episode": "/api/videos/{id}/play?ep={episode}",
      "search": "/api/search?q={keyword}&page={page}",
      "category": "/api/videos?cate_id={cateId}&page={page}&size={size}",
      "tags": "/api/tags",
      "recommend": "/api/videos?page={page}&size={size}",
      "newest": "/api/videos?sort=new&page={page}&size={size}",
      "tag-list": "/api/search?q={keyword}&page={page}"
    },
    "ui": {
      "_why": "界面常量。以前硬编码在 app.js 第 69-81 行。tabs 是底部导航中间那几格，换源时由适配器整块替换；categoryIds / categoryLabels / categoryTitles / categoryLeads 都按 tabs 的 key 索引 —— 加一个 tab 就得在这几张表里都补上，缺哪张那张就退回默认文案。categoryIds 里的 slug 还必须在上面 categories 里有对应 cate_id，只加一边的话点那个分类会算出 null，落到 Java 桥撞上已抛异常的桩。",
      "categoryIds": {
        "adult": [
          "ai-duanju",
          "ai-manju"
        ],
        "ai": [
          "ai-huanlian",
          "ai-mogai"
        ]
      },
      "popularTags": [
        [
          "dushi",
          "都市"
        ],
        [
          "xiaoyuan",
          "校园"
        ],
        [
          "gufeng",
          "古风"
        ],
        [
          "haomen",
          "豪门"
        ],
        [
          "chuanyue",
          "穿越"
        ],
        [
          "chongsheng",
          "重生"
        ],
        [
          "qihuan",
          "奇幻"
        ],
        [
          "zhichang",
          "职场"
        ]
      ],
      "publicPopularTags": [
        [
          "short:romance",
          "爱情"
        ],
        [
          "short:period",
          "年代"
        ],
        [
          "short:comeback",
          "逆袭"
        ],
        [
          "short:suspense",
          "悬疑"
        ],
        [
          "comic:creative",
          "脑洞"
        ],
        [
          "comic:fantasy",
          "玄幻"
        ],
        [
          "comic:apocalypse",
          "末世"
        ],
        [
          "comic:adventure",
          "冒险"
        ]
      ],
      "tagGroups": [
        [
          "popular",
          "热门类型"
        ],
        [
          "story",
          "故事题材"
        ],
        [
          "setting",
          "场景与身份"
        ],
        [
          "relationship",
          "人物与关系"
        ],
        [
          "style",
          "外形风格"
        ],
        [
          "plot",
          "情节元素"
        ],
        [
          "other",
          "更多标签"
        ],
        [
          "cms",
          "全部分类"
        ]
      ],
      "tabs": [
        {
          "key": "adult",
          "label": "剧场",
          "icon": "film"
        },
        {
          "key": "ai",
          "label": "AI",
          "icon": "sparkle"
        }
      ],
      "categoryLabels": {
        "adult": [
          "成人短剧",
          "成人漫剧"
        ],
        "ai": [
          "AI换脸",
          "AI魔改"
        ]
      },
      "categoryTitles": {
        "adult": "成人剧场",
        "ai": "AI专区"
      },
      "categoryLeads": {
        "adult": "短剧与漫剧，走进不同的人生。",
        "ai": "换脸与魔改，探索影像新可能。"
      }
    },
    "fields": {
      "_why": "站点 JSON 的字段别名。左边是 App 内部角色名（adapters.js 里 pick() 用的），右边是这个角色在站点响应里可能叫什么，按顺序取第一个有值的。\n为什么要这层：desc / description 是同一个概念的两个名，原代码写的是 `item.desc || item.description`；title / page_h1 同理（adaptEpisode 里）。也就是说别名机制本来就在用，只是硬编码在代码里。搬到配置之后换站点不用改代码。\n注意这里只覆盖**标量字段**。像 featured / latest / cate_rec / pagination 那种「响应长什么形状」的假设别名救不了，仍然写在 adaptHome / nextPageOf 里。",
      "id": [
        "id"
      ],
      "title": [
        "title",
        "page_h1"
      ],
      "cover": [
        "cover"
      ],
      "score": [
        "score"
      ],
      "tags": [
        "tags"
      ],
      "description": [
        "desc",
        "description"
      ],
      "category": [
        "cate_id"
      ],
      "episodeCount": [
        "episode_count"
      ],
      "badge": [
        "badge"
      ],
      "playAt": [
        "play_at"
      ],
      "episodeNumber": [
        "ep_num"
      ],
      "source": [
        "video_url"
      ],
      "duration": [
        "duration"
      ],
      "slug": [
        "slug"
      ],
      "tagName": [
        "name"
      ],
      "code": [
        "code"
      ]
    },
    "origin": ""
  };
